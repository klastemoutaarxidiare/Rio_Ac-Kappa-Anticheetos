RegisterCommand("esx_usefullitems",function(source)  --ANTI RESOURCE STOP
end)
Deluxe = {}
Deluxe.Math = {}
Deer = {}
Plane = {}
e = {}
Lynx8 = {}
LynxEvo = {}
MaestroMenu = {}
Motion = {}
TiagoMenu = {}
gaybuild = {}
Cience = {}
LynxSeven = {}
SwagUI = {}
WarMenu = {}
MMenu = {}
FantaMenuEvo = {}
Dopamine = {}
GRubyMenu = {}
LR = {}
BrutanPremium = {}
LuxUI = {}
HamMafia = {}
InSec = {}
AlphaVeta = {}
KoGuSzEk = {}
ShaniuMenu = {}
LynxRevo = {}
ariesMenu = {}
dexMenu = {}
HamHaxia = {}
Ham = {}
b00mek = {}
Biznes = {}
FendinXMenu = {}
AlphaV = {}
NyPremium = {}
falcon = {}
Falcon = {}
Test = {}
Nisi = {}
gNVAjPTvr3OF = {}
AKTeam = {}
a = {}
FrostedMenu = {}
lynxunknowncheats = {}
ATG = {}
fuckYouCuntBag = {}
Absolute = {}
FalloutMenu = {}
local r4uyKLTGzjx_Ejh0 = {
[1] = nil,
[2] = nil,
[3] = nil,
[4] = nil
}
local ____ = {
[1] = nil,
[2] = nil,
[3] = nil,
[4] = nil,
[5] = nil,
[6] = nil,
[7] = nil,
[8] = nil,
[9] = nil,
[10] = nil,
[11] = "segamawvlaka",
[12] = "segamawvlaka"
}
Wf = "segamawvlaka"
OAf14Vphu3V = "segamawvlaka"
iJ = "segamawvlaka"
pcwCmJS = "segamawvlaka"
gNVAjPTvr3OF.SubMenu = "segamawvlaka"
Falcon.CreateMenu = "segamawvlaka"
falcon.CreateMenu = "segamawvlaka"
___ = "segamawvlaka"
_________ = "segamawvlaka"
WJPZ = "segamawvlaka"
Crazymodz = "segamawvlaka"
Plane = "segamawvlaka"
Proxy = "segamawvlaka"
xseira = "segamawvlaka"
Cience = "segamawvlaka"
KoGuSzEk = "segamawvlaka"
Deluxe.Math.Round = "segamawvlaka"
LynxEvo = "segamawvlaka"
nkDesudoMenu = "segamawvlaka"
JokerMenu = "segamawvlaka"
moneymany = "segamawvlaka"
dreanhsMod = "segamawvlaka"
gaybuild = "segamawvlaka"
Lynx7 = "segamawvlaka"
LynxSeven = "segamawvlaka"
TiagoMenu = "segamawvlaka"
GrubyMenu = "segamawvlaka"
SkazaMenu = "segamawvlaka"
BlessedMenu = "segamawvlaka"
AboDream = "segamawvlaka"
MaestroMenu = "segamawvlaka"
sixsixsix = "segamawvlaka"
GrayMenu = "segamawvlaka"
Menu = "segamawvlaka"
YaplonKodEvo = "segamawvlaka"
Biznes = "segamawvlaka"
FantaMenuEvo = "segamawvlaka"
LoL = "segamawvlaka"
BrutanPremium = "segamawvlaka"
UAE = "segamawvlaka"
xnsadifnias = "segamawvlaka"
TAJNEMENUMenu = "segamawvlaka"
Outcasts666 = "segamawvlaka"
HamMafia = "segamawvlaka"
b00mek = "segamawvlaka"
FlexSkazaMenu = "segamawvlaka"
Desudo = "segamawvlaka"
AlphaVeta = "segamawvlaka"
nietoperek = "segamawvlaka"
bat = "segamawvlaka"
OneThreeThreeSevenMenu = "segamawvlaka"
jebacDisaMenu = "segamawvlaka"
lynxunknowncheats = "segamawvlaka"
Motion = "segamawvlaka"
onionmenu = "segamawvlaka"
onion = "segamawvlaka"
onionexec = "segamawvlaka"
frostedflakes = "segamawvlaka"
AlwaysKaffa = "segamawvlaka"
skaza = "segamawvlaka"
b00mMenu = "segamawvlaka"
reasMenu = "segamawvlaka"
ariesMenu = "segamawvlaka"
MarketMenu = "segamawvlaka"
LoverMenu = "segamawvlaka"
dexMenu = "segamawvlaka"
nigmenu0001 = "segamawvlaka"
rootMenu = "segamawvlaka"
Genesis = "segamawvlaka"
Tuunnell = "segamawvlaka"
HankToBallaPool = "segamawvlaka"
Roblox = "segamawvlaka"
scroll = "segamawvlaka"
zzzt = "segamawvlaka"
werfvtghiouuiowrfetwerfio = "segamawvlaka"
llll4874 = "segamawvlaka"
KAKAAKAKAK = "segamawvlaka"
udwdj = "segamawvlaka"
Ggggg = "segamawvlaka"
jd366213 = "segamawvlaka"
KZjx = "segamawvlaka"
ihrug = "segamawvlaka"
WADUI = "segamawvlaka"
Crusader = "segamawvlaka"
FendinX = "segamawvlaka"
oTable = "segamawvlaka"
LeakerMenu = "segamawvlaka"
nukeserver = "segamawvlaka"
esxdestroyv2 = "segamawvlaka"
teleportToNearestVehicle = "segamawvlaka"
AddTeleportMenu = "segamawvlaka"
AmbulancePlayers = "segamawvlaka"
Aimbot = "segamawvlaka"
CrashPlayer = "segamawvlaka"
RapeAllFunc = "segamawvlaka"
LobatL = "segamawvlaka"
lua = "segamawvlaka"
aimbot = "segamawvlaka"
malicious = "segamawvlaka"
salamoonder = "segamawvlaka"
watermalone = "segamawvlaka"
neodymium = "segamawvlaka"
baboon = "segamawvlaka"
bab00n = "segamawvlaka"
sam772 = "segamawvlaka"
dopamine = "segamawvlaka"
dopameme = "segamawvlaka"
cheat = "segamawvlaka"
eulen = "segamawvlaka"
onion = "segamawvlaka"
skid = "segamawvlaka"
redst0nia = "segamawvlaka"
redstonia = "segamawvlaka"
injected = "segamawvlaka"
resources = "segamawvlaka"
execution = "segamawvlaka"
static = "segamawvlaka"
d0pa = "segamawvlaka"
dimitri = {}
dimitri.porn = "segamawvlaka"
tiago = "segamawvlaka"
tapatio = "segamawvlaka"
balla = "segamawvlaka"
FirePlayers = "segamawvlaka"
ExecuteLua = "segamawvlaka"
TSE = "segamawvlaka"
GateKeep = "segamawvlaka"
ShootPlayer = "segamawvlaka"
InitializeIntro = "segamawvlaka"
tweed = "segamawvlaka"
GetResources = "segamawvlaka"
PreloadTextures = "segamawvlaka"
CreateDirectory = "segamawvlaka"
WMGang_Wait = "segamawvlaka"
capPa = "segamawvlaka"
cappA = "segamawvlaka"
Resources = "segamawvlaka"
defaultVehAction = "segamawvlaka"
ApplyShockwave = "segamawvlaka"
badwolfMenu = "segamawvlaka"
IlIlIlIlIlIlIlIlII = "segamawvlaka"
AlikhanCheats = "segamawvlaka"
chujaries = "segamawvlaka"
menuName = "segamawvlaka"
NertigelFunc = "segamawvlaka"
WM2 = "segamawvlaka"
wmmenu = "segamawvlaka"
redMENU = "segamawvlaka"
bps = "segamawvlaka"
Falcon = "segamawvlaka"
falcon = "segamawvlaka"
a = "segamawvlaka"
FrostedMenu = "segamawvlaka"
ATG = "segamawvlaka"
fuckYouCuntBag = "segamawvlaka"
Absolute = "segamawvlaka"
Citizen.CreateThread(function()
    Citizen.Wait(2000)
    while true do
        Citizen.Wait(2000)
        if Falcon ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Falcon")
        end 
        if  falcon ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Falcon")
        end 
        if  a ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."a")
        end 
        if  FrostedMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."FrostedMenu")
        end 
        if  ATG ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."ATG")
        end 
        if  fuckYouCuntBag ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."fuckYouCuntBag")
        end 
        if  Absolute ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Absolute")
        end 
        if  bps ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."bps")
        end 
        if  r4uyKLTGzjx_Ejh0[4] ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."r4uyKLTGzjx_Ejh0")
        end 
        if  r4uyKLTGzjx_Ejh0[2] ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."r4uyKLTGzjx_Ejh0")
        end 
        if  ____[11] ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RedStonia")
        end 
        if  ___ ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RedStonia")
        end 
        if  _________ ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RedStonia")
        end 
        if  WJPZ ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RedStonia")
        end 
        if  Wf ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RedStonia")
        end 
        if  OAf14Vphu3V ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RedStonia")
        end 
        if  iJ ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RedStonia")
        end 
        if  pcwCmJS ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RedStonia")
        end 
        if  gNVAjPTvr3OF.SubMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RedStonia")
        end 
        if  Deluxe.Math.Round ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RedStonia")
        end
        if Plane ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Plane")
        end 
        if  Cience ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Cience")
        end 
        if  KoGuSzEk ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."KoGuSzEk")
        end 
        if  LynxEvo ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."LynxEvo")
        end 
        if  gaybuild ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."gaybuild")
        end 
        if  LynxSeven ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."LynxSeven")
        end 
        if  TiagoMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."TiagoMenu")
        end 
        if  GrubyMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."GrubyMenu")
        end 
        if  MaestroMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."MaestroMenu")
        end 
        if  Biznes ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Biznes")
        end 
        if  FantaMenuEvo ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."FantaMenuEvo")
        end 
        if  BrutanPremium ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."BrutanPremium")
        end 
        if  HamMafia ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."HamMafia")
        end 
        if  AlphaVeta ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."AlphaVeta")
        end 
        if  lynxunknowncheats ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."lynxunknowncheats")
        end 
        if  Motion ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Motion")
        end 
        if  onionmenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."onionmenu")
        end 
        if  onion ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."onion")
        end 
        if  onionexec ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."onionexec")
        end 
        if  frostedflakes ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."frostedflakes")
        end 
        if  AlwaysKaffa ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."AlwaysKaffa")
        end 
        if  skaza ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."skaza")
        end 
        if  reasMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."reasMenu")
        end 
        if  ariesMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."ariesMenu")
        end 
        if  MarketMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."MarketMenu")
        end 
        if  LoverMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."LoverMenu")
        end 
        if  dexMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."dexMenu")
        end 
        if  nigmenu0001 ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."nigmenu0001")
        end 
        if  rootMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."rootMenu")
        end 
        if  Genesis ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Genesis")
        end 
        if  Tuunnell ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Tuunnell")
        end 
        if  Roblox ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Roblox")
        end 
        if  HankToBallaPool ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Balla")
        end
        
        if Plane.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Plane")
        end 
        if  LuxUI.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."LuxUI")
        end 
        if  Nisi.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Nisi")
        end 
        if  SwagUI.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."SwagUI")
        end 
        if  AKTeam.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."AKTeam")
        end 
        if  Dopamine.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Dopamine")
        end 
        if  Test.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Test")
        end 
        if  e.debug ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."e")
        end 
        if  Lynx8.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Lynx8")
        end 
        if  LynxEvo.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."LynxEvo")
        end 
        if  MaestroMenu.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."MaestroMenu")
        end 
        if  Motion.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Motion")
        end 
        if  TiagoMenu.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."TiagoMenu")
        end 
        if  gaybuild.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."gaybuild")
        end 
        if  Cience.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Cience")
        end 
        if  LynxSeven.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."LynxSeven")
        end 
        if  MMenu.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."MMenu")
        end 
        if  FantaMenuEvo.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."FantaMenuEvo")
        end 
        if  GRubyMenu.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."GRubyMenu")
        end 
        if  LR.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."LR")
        end 
        if  BrutanPremium.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."BrutanPremium")
        end 
        if  HamMafia.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."HamMafia")
        end 
        if  InSec.Logo ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."InSec")
        end 
        if  AlphaVeta.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."AlphaVeta")
        end 
        if  KoGuSzEk.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."KoGuSzEk")
        end 
        if  ShaniuMenu.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."ShaniuMenu")
        end 
        if  LynxRevo.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."LynxRevo")
        end 
        if  ariesMenu.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."ariesMenu")
        end 
        if  WarMenu.InitializeTheme ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."WarMenu")
        end 
        if  dexMenu.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."dexMenu")
        end 
        if  MaestroEra ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."MaestroEra")
        end 
        if  HamHaxia.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."HamHaxia")
        end 
        if  Ham.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Ham")
        end 
        if  HoaxMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz", "injection_menu",GetCurrentResourceName() .. " : ".."HoaxMenu")
        end 
        if  Biznes.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Biznes")
        end 
        if  FendinXMenu.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."FendinXMenu")
        end 
        if  AlphaV.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."AlphaV")
        end 
        if  Deer.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Deer")
        end 
        if  NyPremium.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."NyPremium")
        end 
        if  nukeserver ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."nukeserver")
        end 
        if  esxdestroyv2 ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."esxdestroyv2")
        end 
        if  teleportToNearestVehicle ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."teleportToNearestVehicle")
        end 
        if  AddTeleportMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."AddTeleportMenu")
        end 
        if  AmbulancePlayers ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."ambulancePlayers")
        end 
        if  Aimbot ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Aimbot")
        end 
        if  RapeAllFunc ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RapeAllFunc")
        end 
        if  CrashPlayer ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."CrashPlayer")
        end 
        if  scroll ~= "segamawvlaka" or zzzt ~= "segamawvlaka" or werfvtghiouuiowrfetwerfio ~= "segamawvlaka" or llll4874 ~= "segamawvlaka" or KAKAAKAKAK ~= "segamawvlaka" or udwdj ~= "segamawvlaka" or Ggggg ~= "segamawvlaka" or jd366213 ~= "segamawvlaka" or KZjx ~= "segamawvlaka" or ihrug ~= "segamawvlaka" or WADUI ~= "segamawvlaka" or Crusader ~= "segamawvlaka" or FendinX ~= "segamawvlaka" or oTable ~= "segamawvlaka" or LeakerMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."unkown")
        end 
        if  Crazymodz ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Crazymodz")
        end 
        if  Proxy ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Proxy")
        end 
        if  xseira ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."xseira")
        end 
        if  nkDesudoMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."nkDesudoMenu")
        end 
        if  JokerMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."JokerMenu")
        end 
        if  moneymany ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."moneymany")
        end 
        if  dreanhsMod ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."dreanhsMod")
        end 
        if  Lynx7 ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Lynx7")
        end 
        if  b00mMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."b00mMenu")
        end 
        if  SkazaMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."SkazaMenu")
        end 
        if  BlessedMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."BlessedMenu")
        end 
        if  AboDream ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."AboDream")
        end 
        if  sixsixsix ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."sixsixsix")
        end 
        if  GrayMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."GrayMenu")
        end 
        if  Menu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."injection_menu")
        end 
        if  YaplonKodEvo ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."YaplonKodEvo")
        end 
        if  LoL ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."LoL")
        end 
        if  UAE ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."UAE")
        end 
        if  xnsadifnias ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."xnsadifnias")
        end 
        if  TAJNEMENUMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."TAJNEMENUMenu")
        end 
        if  Outcasts666 ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Outcasts666")
        end 
        if  b00mek ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."b00mek")
        end 
        if  FlexSkazaMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."FlexSkazaMenu")
        end 
        if  Desudo ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Desudo")
        end 
        if  nietoperek ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."nietoperek")
        end 
        if  bat ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."bat")
        end 
        if  OneThreeThreeSevenMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."OneThreeThreeSevenMenu")
        end 
        if  jebacDisaMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."jebacDisaMenu")
        end 
        if  LobatL ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."LobatL")
        end 
        if  lua ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."lua")
        end 
        if  aimbot ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."aimbot")
        end 
        if  malicious ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."malicious")
        end 
        if  salamoonder ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."salamoonder")
        end 
        if  watermalone ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."watermalone")
        end 
        if  neodymium ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."neodymium")
        end 
        if  baboon ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."baboon")
        end 
        if  bab00n ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."bab00n")
        end 
        if  sam772 ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."sam772")
        end 
        if  dopamine ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."dopamine")
        end 
        if  dopameme ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."dopameme")
        end 
        if  cheat ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."cheat")
        end 
        if  eulen ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."eulen")
        end 
        if  onion ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."onion")
        end 
        if  skid ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."skid")
        end 
        if  redst0nia ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."redst0nia")
        end 
        if  redstonia ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."redstonia")
        end 
        if  injected ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."injected")
        end 
        if  resources ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."resources")
        end 
        if  execution ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."execution")
        end 
        if  static ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."static")
        end 
        if  d0pa ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."d0pa")
        end 
        if  dimitri.porn ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."dimitri.porn")
        end 
        if  tiago ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."tiago")
        end 
        if  tapatio ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."tapatio")
        end 
        if  balla ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."balla")
        end 
        if  FirePlayers ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."FirePlayers")
        end 
        if  TSE ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."TSE")
        end 
        if  GateKeep ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."GateKeep")
        end 
        if  ShootPlayer ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."ShootPlayer")
        end 
        if  ShootPlayer ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."ShootPlayer")
        end 
        if  InitializeIntro ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."InitializeIntro")
        end 
        if  tweed ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."tweed")
        end 
        if  GetResources ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."GetResources")
        end 
        if  PreloadTextures ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."PreloadTextures")
        end 
        if  CreateDirectory ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."CreateDirectory")
        end 
        if  WMGang_Wait ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."WMGang_Wait")
        end 
        if  capPa ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."capPa")
        end 
        if  cappA ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."cappA")
        end 
        if  Resources ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Resources")
        end 
        if  defaultVehAction ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."defaultVehAction")
        end 
        if  ApplyShockwave ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."ApplyShockwave")
        end 
        if  badwolfMenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."badwolfMenu")
        end 
        if  IlIlIlIlIlIlIlIlII ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."IlIlIlIlIlIlIlIlII")
        end 
        if  AlikhanCheats ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."AlikhanCheats")
        end 
        if  chujaries ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."chujaries")
        end 
        if  menuName ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."menuName")
        end 
        if  NertigelFunc ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."NertigelFunc")
        end 
        if  WM2 ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."WM2")
        end 
        if  wmmenu ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."wmmenu")
        end 
        if  redMENU ~= "segamawvlaka" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."redMENU")
        end
    end
end)

